# PowerTracker Flutter App - Reference Code

This folder contains the complete Flutter/Dart code for the PowerTracker energy consumption tracking app.

## 📁 Project Structure

```
lib/
├── main.dart                      # Main app entry point with navigation
├── models/
│   └── device.dart               # Device data model
└── screens/
    ├── home_screen.dart          # Home screen with usage cards & device controls
    ├── devices_screen.dart       # Devices list screen
    ├── analytics_screen.dart     # Analytics with charts
    └── settings_screen.dart      # Settings screen
```

## 🚀 Setup Instructions

### 1. Create a New Flutter Project

```bash
flutter create power_tracker
cd power_tracker
```

### 2. Replace Files

Copy all the files from this `/flutter_reference` folder to your Flutter project:

- Copy `main.dart` to `lib/main.dart`
- Copy the `screens/` folder to `lib/screens/`
- Copy the `models/` folder to `lib/models/`
- Replace `pubspec.yaml` with the provided one

### 3. Install Dependencies

```bash
flutter pub get
```

### 4. Run the App

```bash
flutter run
```

## 📦 Dependencies

The app uses the following packages:

- **fl_chart** (^0.66.0) - For creating interactive charts in the Analytics screen
- **cupertino_icons** - For iOS-style icons

## ✨ Features Implemented

### Home Screen
- ✅ Real-time power usage card (updates dynamically)
- ✅ Estimated monthly bill in PHP (₱6,850.00)
- ✅ Quick device controls with toggle functionality
- ✅ Add new devices with custom name, power, and icon
- ✅ Remove mode toggle to delete devices
- ✅ 8 different icon options for devices

### Devices Screen
- ✅ List of all connected devices
- ✅ Toggle switches for each device
- ✅ Room location and power consumption info
- ✅ Color-coded icons

### Analytics Screen
- ✅ Interactive line chart showing weekly energy usage
- ✅ Period selector (Day, Week, Month, Year)
- ✅ Statistics cards (Average, Peak, Lowest, Total Cost)
- ✅ Gradient area chart with fl_chart

### Settings Screen
- ✅ User profile section with edit button
- ✅ Toggle switches for notifications, dark mode, auto reports
- ✅ Account settings (Billing, Energy Plans, Privacy)
- ✅ Support options (Help Center, Contact, About)
- ✅ Logout button

### Navigation
- ✅ Bottom navigation bar with 4 tabs
- ✅ Header with PowerTracker logo
- ✅ Side drawer menu with user profile
- ✅ Menu options (Account Settings, Notifications, Privacy, Help, About)
- ✅ Logout button in drawer

## 🎨 Design Features

- **Color Scheme**: Blue/Purple gradient theme matching your design
- **Typography**: Clean, modern font hierarchy
- **Layout**: Mobile-optimized with proper spacing and padding
- **Components**: Material Design widgets with custom styling
- **Responsive**: Adapts to different screen sizes

## 🔄 State Management

The app uses basic `setState()` for state management:
- Device list management (add, remove, toggle)
- Switch states for settings
- Tab navigation
- Chart period selection

For a production app, consider using:
- Provider
- Riverpod
- Bloc
- GetX

## 🛠 Customization

### Change Colors
Edit the theme in `main.dart`:
```dart
theme: ThemeData(
  primarySwatch: Colors.blue, // Change primary color
  scaffoldBackgroundColor: const Color(0xFFF8FAFC), // Background
),
```

### Add More Icons
Edit `DeviceIcon.availableIcons` in `models/device.dart`

### Modify Chart Data
Edit `weeklyData` in `screens/analytics_screen.dart`

## 📱 Testing

Test on different devices:
```bash
# iOS Simulator
flutter run -d ios

# Android Emulator
flutter run -d android

# Chrome (for web testing)
flutter run -d chrome
```

## 🐛 Troubleshooting

### Chart not showing?
Make sure `fl_chart` is installed:
```bash
flutter pub get
```

### Build errors?
Clean and rebuild:
```bash
flutter clean
flutter pub get
flutter run
```

### Hot reload not working?
Restart the app:
```bash
# Press 'r' in terminal for hot reload
# Press 'R' in terminal for hot restart
```

## 📝 Notes

- The current implementation uses mock data
- To persist data, integrate with a backend (Firebase, Supabase, etc.)
- For real-time device control, integrate with IoT APIs
- Consider adding user authentication for production
- Add error handling and loading states
- Implement dark mode theme switching

## 🚀 Next Steps

1. **Database Integration**: Add Firebase or Supabase for data persistence
2. **User Authentication**: Implement login/signup with email/social auth
3. **Real Device Integration**: Connect to actual IoT devices via APIs
4. **Push Notifications**: Set up FCM for usage alerts
5. **Dark Mode**: Complete dark theme implementation
6. **Localization**: Add multi-language support
7. **Analytics**: Integrate Firebase Analytics or similar
8. **Testing**: Add unit and widget tests

---

**Need Help?** 
- Flutter Documentation: https://docs.flutter.dev
- fl_chart Documentation: https://pub.dev/packages/fl_chart
- Flutter Community: https://flutter.dev/community
