import 'package:flutter/material.dart';

class Device {
  final String id;
  final String name;
  final int power;
  bool active;
  final IconData icon;
  final Color iconColor;

  Device({
    required this.id,
    required this.name,
    required this.power,
    required this.active,
    required this.icon,
    required this.iconColor,
  });
}

class DeviceIcon {
  final IconData icon;
  final Color color;
  final String name;

  DeviceIcon({
    required this.icon,
    required this.color,
    required this.name,
  });

  static List<DeviceIcon> availableIcons = [
    DeviceIcon(icon: Icons.ac_unit, color: Colors.blue, name: 'Air Conditioner'),
    DeviceIcon(icon: Icons.kitchen, color: Colors.green, name: 'Kitchen Appliance'),
    DeviceIcon(icon: Icons.tv, color: Colors.purple, name: 'TV'),
    DeviceIcon(icon: Icons.lightbulb, color: Colors.yellow, name: 'Light'),
    DeviceIcon(icon: Icons.emoji_objects, color: Colors.orange, name: 'Lamp'),
    DeviceIcon(icon: Icons.air, color: Colors.cyan, name: 'Fan'),
    DeviceIcon(icon: Icons.monitor, color: Colors.indigo, name: 'Monitor'),
    DeviceIcon(icon: Icons.speaker, color: Colors.pink, name: 'Speaker'),
  ];
}
