import 'package:flutter/material.dart';
import '../models/device.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Device> devices = [
    Device(
      id: '1',
      name: 'Living Room AC',
      power: 1200,
      active: true,
      icon: Icons.ac_unit,
      iconColor: Colors.blue,
    ),
    Device(
      id: '2',
      name: 'Refrigerator',
      power: 150,
      active: true,
      icon: Icons.kitchen,
      iconColor: Colors.green,
    ),
    Device(
      id: '3',
      name: 'Smart TV',
      power: 0,
      active: false,
      icon: Icons.tv,
      iconColor: Colors.purple,
    ),
    Device(
      id: '4',
      name: 'LED Lights',
      power: 45,
      active: true,
      icon: Icons.lightbulb,
      iconColor: Colors.yellow,
    ),
  ];

  bool isRemoveMode = false;

  int get totalUsage {
    return devices.fold(0, (sum, device) => sum + (device.active ? device.power : 0));
  }

  void toggleDevice(String id) {
    setState(() {
      final index = devices.indexWhere((d) => d.id == id);
      if (index != -1) {
        devices[index].active = !devices[index].active;
      }
    });
  }

  void removeDevice(String id) {
    setState(() {
      devices.removeWhere((device) => device.id == id);
    });
  }

  void showAddDeviceDialog() {
    final nameController = TextEditingController();
    final powerController = TextEditingController();
    int selectedIconIndex = 0;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Add New Device'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Device Name', style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        hintText: 'e.g., Bedroom Fan',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Power Consumption (Watts)', style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: powerController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        hintText: 'e.g., 75',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text('Select Icon', style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        crossAxisSpacing: 8,
                        mainAxisSpacing: 8,
                      ),
                      itemCount: DeviceIcon.availableIcons.length,
                      itemBuilder: (context, index) {
                        final iconOption = DeviceIcon.availableIcons[index];
                        final isSelected = selectedIconIndex == index;
                        return InkWell(
                          onTap: () {
                            setDialogState(() {
                              selectedIconIndex = index;
                            });
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: isSelected ? const Color(0xFF6366F1) : Colors.grey[300]!,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(12),
                              color: isSelected ? const Color(0xFFEEF2FF) : Colors.white,
                            ),
                            child: Center(
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: iconOption.color,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  iconOption.icon,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (nameController.text.trim().isEmpty || powerController.text.isEmpty) {
                      return;
                    }
                    final selectedIcon = DeviceIcon.availableIcons[selectedIconIndex];
                    final newDevice = Device(
                      id: DateTime.now().millisecondsSinceEpoch.toString(),
                      name: nameController.text,
                      power: int.tryParse(powerController.text) ?? 0,
                      active: false,
                      icon: selectedIcon.icon,
                      iconColor: selectedIcon.color,
                    );
                    setState(() {
                      devices.add(newDevice);
                    });
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6366F1),
                  ),
                  child: const Text('Add Device'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Current Usage Card
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF3B82F6), Color(0xFF4F46E5)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.bolt, color: Colors.white, size: 32),
                  Text(
                    'Real-time',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                '${totalUsage}W',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Current Usage',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        
        // Estimated Bill Card
        Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF10B981), Color(0xFF059669)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Icon(Icons.attach_money, color: Colors.white, size: 32),
                  Text(
                    'Monthly Est.',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                '₱6,850.00',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Estimated Bill',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.9),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        
        // Quick Controls Header
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Quick Controls',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    setState(() {
                      isRemoveMode = !isRemoveMode;
                    });
                  },
                  icon: const Icon(Icons.delete_outline, size: 16),
                  label: Text(isRemoveMode ? 'Done' : 'Remove'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isRemoveMode ? Colors.red : Colors.grey[300],
                    foregroundColor: isRemoveMode ? Colors.white : Colors.grey[700],
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 14),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: showAddDeviceDialog,
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Add'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6366F1),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 14),
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        
        // Device Grid
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 0.95,
          ),
          itemCount: devices.length,
          itemBuilder: (context, index) {
            final device = devices[index];
            return Stack(
              children: [
                GestureDetector(
                  onTap: isRemoveMode ? null : () => toggleDevice(device.id),
                  child: Opacity(
                    opacity: isRemoveMode ? 0.75 : 1.0,
                    child: Container(
                      decoration: BoxDecoration(
                        color: device.active ? Colors.white : Colors.grey[50],
                        border: Border.all(
                          color: device.active ? const Color(0xFF6366F1) : Colors.grey[200]!,
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: device.iconColor,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(device.icon, color: Colors.white, size: 24),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            device.name,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: device.active
                                      ? const Color(0xFFD1FAE5)
                                      : Colors.grey[200],
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  device.active ? 'ON' : 'OFF',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: device.active
                                        ? const Color(0xFF047857)
                                        : Colors.grey[600],
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${device.active ? device.power : 0}W',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[500],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (isRemoveMode)
                  Positioned(
                    top: -4,
                    right: -4,
                    child: GestureDetector(
                      onTap: () => removeDevice(device.id),
                      child: Container(
                        width: 24,
                        height: 24,
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 4,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 16,
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}
