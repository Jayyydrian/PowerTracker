import 'package:flutter/material.dart';

class DevicesScreen extends StatefulWidget {
  const DevicesScreen({Key? key}) : super(key: key);

  @override
  State<DevicesScreen> createState() => _DevicesScreenState();
}

class _DevicesScreenState extends State<DevicesScreen> {
  final List<Map<String, dynamic>> devices = [
    {
      'name': 'Living Room AC',
      'room': 'Living Room',
      'power': '1200W',
      'status': 'On',
      'icon': Icons.ac_unit,
      'color': Colors.blue,
      'isOn': true,
    },
    {
      'name': 'Refrigerator',
      'room': 'Kitchen',
      'power': '150W',
      'status': 'On',
      'icon': Icons.kitchen,
      'color': Colors.green,
      'isOn': true,
    },
    {
      'name': 'Smart TV',
      'room': 'Living Room',
      'power': '0W',
      'status': 'Off',
      'icon': Icons.tv,
      'color': Colors.purple,
      'isOn': false,
    },
    {
      'name': 'LED Lights',
      'room': 'Bedroom',
      'power': '45W',
      'status': 'On',
      'icon': Icons.lightbulb,
      'color': Colors.yellow,
      'isOn': true,
    },
    {
      'name': 'Washing Machine',
      'room': 'Laundry',
      'power': '0W',
      'status': 'Off',
      'icon': Icons.local_laundry_service,
      'color': Colors.teal,
      'isOn': false,
    },
  ];

  void toggleDevice(int index) {
    setState(() {
      devices[index]['isOn'] = !devices[index]['isOn'];
      devices[index]['status'] = devices[index]['isOn'] ? 'On' : 'Off';
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'My Devices',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          '${devices.length} devices connected',
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 20),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: devices.length,
          separatorBuilder: (context, index) => const SizedBox(height: 12),
          itemBuilder: (context, index) {
            final device = devices[index];
            return Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey[200]!),
              ),
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: device['color'].withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      device['icon'],
                      color: device['color'],
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device['name'],
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          device['room'],
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          device['power'],
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[500],
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Switch(
                    value: device['isOn'],
                    onChanged: (value) => toggleDevice(index),
                    activeColor: const Color(0xFF6366F1),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }
}
