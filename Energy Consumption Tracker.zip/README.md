
  # Energy Consumption Tracker

  This is a code bundle for Energy Consumption Tracker. The original project is available at https://www.figma.com/design/MGFaHbn5agwnPKQ8cG9e8H/Energy-Consumption-Tracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  