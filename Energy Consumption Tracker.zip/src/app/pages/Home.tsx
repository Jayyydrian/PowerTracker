import { Zap, DollarSign, AirVent, Coffee, Tv, Lightbulb, Plus, X, Lamp, Fan, Monitor, Speaker, Trash2 } from "lucide-react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../components/ui/dialog";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";

interface Device {
  id: string;
  name: string;
  power: number;
  active: boolean;
  icon: React.ComponentType<{ className?: string }>;
  iconColor: string;
}

const availableIcons = [
  { icon: AirVent, color: "bg-blue-500", name: "Air Conditioner" },
  { icon: Coffee, color: "bg-green-500", name: "Kitchen Appliance" },
  { icon: Tv, color: "bg-purple-500", name: "TV" },
  { icon: Lightbulb, color: "bg-yellow-500", name: "Light" },
  { icon: Lamp, color: "bg-orange-500", name: "Lamp" },
  { icon: Fan, color: "bg-cyan-500", name: "Fan" },
  { icon: Monitor, color: "bg-indigo-500", name: "Monitor" },
  { icon: Speaker, color: "bg-pink-500", name: "Speaker" },
];

export function Home() {
  const [devices, setDevices] = useState<Device[]>([
    {
      id: "1",
      name: "Living Room AC",
      power: 1200,
      active: true,
      icon: AirVent,
      iconColor: "bg-blue-500",
    },
    {
      id: "2",
      name: "Refrigerator",
      power: 150,
      active: true,
      icon: Coffee,
      iconColor: "bg-green-500",
    },
    {
      id: "3",
      name: "Smart TV",
      power: 0,
      active: false,
      icon: Tv,
      iconColor: "bg-purple-500",
    },
    {
      id: "4",
      name: "LED Lights",
      power: 45,
      active: true,
      icon: Lightbulb,
      iconColor: "bg-yellow-500",
    },
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState("");
  const [newDevicePower, setNewDevicePower] = useState("");
  const [selectedIconIndex, setSelectedIconIndex] = useState(0);
  const [isRemoveMode, setIsRemoveMode] = useState(false);

  const toggleDevice = (id: string) => {
    setDevices((prev) =>
      prev.map((device) =>
        device.id === id ? { ...device, active: !device.active } : device
      )
    );
  };

  const removeDevice = (id: string) => {
    setDevices((prev) => prev.filter((device) => device.id !== id));
  };

  const addDevice = () => {
    if (!newDeviceName.trim() || !newDevicePower) return;

    const selectedIcon = availableIcons[selectedIconIndex];
    const newDevice: Device = {
      id: Date.now().toString(),
      name: newDeviceName,
      power: parseInt(newDevicePower) || 0,
      active: false,
      icon: selectedIcon.icon,
      iconColor: selectedIcon.color,
    };

    setDevices((prev) => [...prev, newDevice]);
    setIsAddDialogOpen(false);
    setNewDeviceName("");
    setNewDevicePower("");
    setSelectedIconIndex(0);
  };

  const totalUsage = devices.reduce(
    (sum, device) => sum + (device.active ? device.power : 0),
    0
  );

  return (
    <div className="p-4 space-y-4">
      {/* Current Usage Card */}
      <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-3xl p-6 text-white">
        <div className="flex items-start justify-between mb-4">
          <Zap className="w-8 h-8" />
          <span className="text-sm opacity-90">Real-time</span>
        </div>
        <div className="text-5xl font-bold mb-2">{totalUsage}W</div>
        <div className="text-sm opacity-90">Current Usage</div>
      </div>

      {/* Estimated Bill Card */}
      <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-3xl p-6 text-white">
        <div className="flex items-start justify-between mb-4">
          <DollarSign className="w-8 h-8" />
          <span className="text-sm opacity-90">Monthly Est.</span>
        </div>
        <div className="text-5xl font-bold mb-2">₱6,850.00</div>
        <div className="text-sm opacity-90">Estimated Bill</div>
      </div>

      {/* Quick Device Controls */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-gray-900">Quick Controls</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsRemoveMode(!isRemoveMode)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-lg transition-colors ${
                isRemoveMode
                  ? "bg-red-500 text-white hover:bg-red-600"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              <Trash2 className="w-4 h-4" />
              <span className="text-sm font-medium">{isRemoveMode ? "Done" : "Remove"}</span>
            </button>
            <button
              onClick={() => setIsAddDialogOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span className="text-sm font-medium">Add</span>
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {devices.map((device) => {
            const Icon = device.icon;
            return (
              <div key={device.id} className="relative">
                {isRemoveMode && (
                  <button
                    onClick={() => removeDevice(device.id)}
                    className="absolute -top-2 -right-2 z-10 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-all shadow-md animate-in zoom-in duration-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => !isRemoveMode && toggleDevice(device.id)}
                  disabled={isRemoveMode}
                  className={`w-full p-4 rounded-2xl border-2 transition-all ${
                    device.active
                      ? "bg-white border-indigo-500"
                      : "bg-gray-50 border-gray-200"
                  } ${isRemoveMode ? "opacity-75" : ""}`}
                >
                  <div className="flex flex-col items-center gap-2">
                    <div
                      className={`${device.iconColor} w-12 h-12 rounded-xl flex items-center justify-center`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-sm font-medium text-gray-900 text-center">
                      {device.name}
                    </span>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          device.active
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-200 text-gray-600"
                        }`}
                      >
                        {device.active ? "ON" : "OFF"}
                      </span>
                      <span className="text-xs text-gray-500">
                        {device.active ? device.power : 0}W
                      </span>
                    </div>
                  </div>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Device Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Device</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="device-name">Device Name</Label>
              <Input
                id="device-name"
                placeholder="e.g., Bedroom Fan"
                value={newDeviceName}
                onChange={(e) => setNewDeviceName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="device-power">Power Consumption (Watts)</Label>
              <Input
                id="device-power"
                type="number"
                placeholder="e.g., 75"
                value={newDevicePower}
                onChange={(e) => setNewDevicePower(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label>Select Icon</Label>
              <div className="grid grid-cols-4 gap-2">
                {availableIcons.map((iconOption, index) => {
                  const IconComponent = iconOption.icon;
                  return (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setSelectedIconIndex(index)}
                      className={`p-3 rounded-xl border-2 transition-all ${
                        selectedIconIndex === index
                          ? "border-indigo-500 bg-indigo-50"
                          : "border-gray-200 bg-white hover:border-gray-300"
                      }`}
                    >
                      <div
                        className={`${iconOption.color} w-10 h-10 rounded-lg flex items-center justify-center mx-auto`}
                      >
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={addDevice}>Add Device</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}