import { AirVent, Coffee, Tv, Lightbulb } from "lucide-react";
import { Switch } from "../components/ui/switch";
import { useState } from "react";

interface Device {
  id: string;
  name: string;
  location: string;
  power: number;
  active: boolean;
  icon: React.ComponentType<{ className?: string }>;
  iconColor: string;
}

export function Devices() {
  const [devices, setDevices] = useState<Device[]>([
    {
      id: "1",
      name: "Living Room AC",
      location: "Living Room",
      power: 1200,
      active: true,
      icon: AirVent,
      iconColor: "bg-blue-500",
    },
    {
      id: "2",
      name: "Refrigerator",
      location: "Kitchen",
      power: 150,
      active: true,
      icon: Coffee,
      iconColor: "bg-green-500",
    },
    {
      id: "3",
      name: "Smart TV",
      location: "Bedroom",
      power: 0,
      active: false,
      icon: Tv,
      iconColor: "bg-purple-500",
    },
    {
      id: "4",
      name: "LED Lights",
      location: "Living Room",
      power: 45,
      active: true,
      icon: Lightbulb,
      iconColor: "bg-yellow-500",
    },
  ]);

  const toggleDevice = (id: string) => {
    setDevices((prev) =>
      prev.map((device) =>
        device.id === id ? { ...device, active: !device.active } : device
      )
    );
  };

  return (
    <div className="p-4 space-y-3">
      {devices.map((device) => {
        const Icon = device.icon;
        return (
          <div
            key={device.id}
            className="bg-white border border-gray-200 rounded-2xl p-4 flex items-center gap-4"
          >
            <div className={`${device.iconColor} w-12 h-12 rounded-xl flex items-center justify-center`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{device.name}</h3>
              <p className="text-sm text-gray-500">{device.location}</p>
            </div>
            <div className="text-right mr-3">
              <div className="font-semibold text-gray-900">{device.power}W</div>
              <p className="text-xs text-gray-500">
                {device.active ? "Active" : "Standby"}
              </p>
            </div>
            <Switch
              checked={device.active}
              onCheckedChange={() => toggleDevice(device.id)}
            />
          </div>
        );
      })}
    </div>
  );
}
