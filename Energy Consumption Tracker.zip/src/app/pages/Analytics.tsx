import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface DayData {
  day: string;
  percentage: number;
  usage: number;
}

export function Analytics() {
  const weekData: DayData[] = [
    { day: "Mon", percentage: 85, usage: 12.8 },
    { day: "Tue", percentage: 72, usage: 10.8 },
    { day: "Wed", percentage: 90, usage: 13.5 },
    { day: "Thu", percentage: 68, usage: 10.2 },
    { day: "Fri", percentage: 95, usage: 14.3 },
    { day: "Sat", percentage: 45, usage: 6.8 },
    { day: "Sun", percentage: 60, usage: 9.0 },
  ];

  return (
    <div className="p-4 space-y-6">
      {/* Energy Usage Graph */}
      <div className="bg-white border border-gray-200 rounded-2xl p-4">
        <h3 className="font-semibold text-gray-900 mb-4">Weekly Energy Usage</h3>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={weekData}>
            <defs>
              <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0.1} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              dataKey="day" 
              stroke="#9ca3af"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#9ca3af"
              style={{ fontSize: '12px' }}
              label={{ value: 'kWh', angle: -90, position: 'insideLeft', style: { fontSize: '12px' } }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                fontSize: '12px',
              }}
            />
            <Area
              type="monotone"
              dataKey="usage"
              stroke="#6366f1"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorUsage)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Daily Breakdown */}
      <div>
        <h3 className="font-semibold text-gray-900 mb-3">Daily Breakdown</h3>
        <div className="space-y-3">
          {weekData.map((data) => (
            <div
              key={data.day}
              className="bg-white border border-gray-200 rounded-2xl p-4 flex items-center gap-4"
            >
              <div className="w-12 text-center font-medium text-gray-700">
                {data.day}
              </div>
              <div className="flex-1">
                <div className="relative h-10 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-indigo-500 to-blue-600 rounded-full flex items-center justify-center transition-all"
                    style={{ width: `${data.percentage}%` }}
                  >
                    <span className="text-white text-sm font-medium">
                      {data.percentage}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="w-20 text-right font-medium text-gray-700">
                {data.usage} kWh
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}