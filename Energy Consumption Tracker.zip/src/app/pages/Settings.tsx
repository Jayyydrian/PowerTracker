import { Switch } from "../components/ui/switch";
import { Cloud } from "lucide-react";
import { useState } from "react";

export function Settings() {
  const [settings, setSettings] = useState({
    highUsageAlerts: true,
    dailyReports: true,
    budgetWarnings: true,
    deviceOfflineAlerts: true,
  });

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-4 space-y-6">
      {/* Settings List */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <span className="text-gray-900">High usage alerts</span>
          <Switch
            checked={settings.highUsageAlerts}
            onCheckedChange={() => toggleSetting("highUsageAlerts")}
          />
        </div>
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <span className="text-gray-900">Daily reports</span>
          <Switch
            checked={settings.dailyReports}
            onCheckedChange={() => toggleSetting("dailyReports")}
          />
        </div>
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <span className="text-gray-900">Budget warnings</span>
          <Switch
            checked={settings.budgetWarnings}
            onCheckedChange={() => toggleSetting("budgetWarnings")}
          />
        </div>
        <div className="p-4 flex items-center justify-between">
          <span className="text-gray-900">Device offline alerts</span>
          <Switch
            checked={settings.deviceOfflineAlerts}
            onCheckedChange={() => toggleSetting("deviceOfflineAlerts")}
          />
        </div>
      </div>

      {/* Cloud Sync Section */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-3">Cloud Sync</h2>
        <div className="bg-white border border-gray-200 rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
              <Cloud className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Connected to Cloud</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
