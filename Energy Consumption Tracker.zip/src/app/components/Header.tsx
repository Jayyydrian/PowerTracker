import { Bell, Menu, Zap, User, Settings, HelpCircle, LogOut, ChevronRight } from "lucide-react";
import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "./ui/sheet";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    // Logout functionality would go here
    alert("Logging out...");
    setMenuOpen(false);
  };

  return (
    <>
      <header className="bg-white border-b px-4 py-3 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-xl flex items-center justify-center">
            <Zap className="w-6 h-6 text-white fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-2 bg-white border border-gray-300 rounded-full px-3 py-1">
              <span className="font-semibold text-gray-900">PowerTracker</span>
            </div>
            <p className="text-xs text-gray-500 mt-0.5 ml-1">Energy Monitor</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="relative">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          <button onClick={() => setMenuOpen(true)}>
            <Menu className="w-6 h-6 text-gray-600" />
          </button>
        </div>
      </header>

      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side="right" className="w-80 bg-white">
          <SheetHeader>
            <SheetTitle>Menu</SheetTitle>
          </SheetHeader>

          <div className="flex flex-col h-full">
            {/* Profile Section */}
            <div className="p-4 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl mb-6">
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-white" />
                </div>
                <div className="text-white">
                  <h3 className="font-semibold">John Doe</h3>
                  <p className="text-sm opacity-90">john.doe@email.com</p>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <nav className="flex-1 space-y-2">
              <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-900">Account Settings</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>

              <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                  <Settings className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-900">Preferences</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>

              <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-xl transition-colors">
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-5 h-5 text-gray-600" />
                  <span className="text-gray-900">Help & Support</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </nav>

            {/* Logout Button */}
            <div className="mt-auto p-4">
              <button
                onClick={handleLogout}
                className="w-full flex items-center justify-center gap-2 p-4 bg-red-500 hover:bg-red-600 text-white rounded-xl transition-colors"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Logout</span>
              </button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}