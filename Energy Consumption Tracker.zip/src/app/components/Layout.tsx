import { Outlet } from "react-router";
import { Header } from "./Header";
import { Navigation } from "./Navigation";

export function Layout() {
  return (
    <div className="flex justify-center min-h-screen bg-gray-50">
      <div className="w-full max-w-md bg-white min-h-screen flex flex-col shadow-xl">
        <Header />
        <main className="flex-1 overflow-auto pb-20">
          <Outlet />
        </main>
        <Navigation />
      </div>
    </div>
  );
}
