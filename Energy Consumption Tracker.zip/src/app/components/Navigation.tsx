import { Home, TrendingUp, Settings } from "lucide-react";
import { Link, useLocation } from "react-router";

export function Navigation() {
  const location = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/analytics", icon: TrendingUp, label: "Analytics" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg max-w-md mx-auto">
      <div className="flex items-center justify-around px-4 py-3">
        {navItems.map(({ path, icon: Icon, label }) => {
          const isActive = location.pathname === path;
          return (
            <Link
              key={path}
              to={path}
              className="flex flex-col items-center gap-1 flex-1"
            >
              <Icon
                className={`w-6 h-6 ${
                  isActive ? "text-indigo-600" : "text-gray-400"
                }`}
              />
              <span
                className={`text-xs ${
                  isActive ? "text-indigo-600 font-medium" : "text-gray-500"
                }`}
              >
                {label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
